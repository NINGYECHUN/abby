USE abby;

CREATE TABLE `tt_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `goods_name` varchar(2000) DEFAULT NULL COMMENT '商品名称',
  `qty` int(11) DEFAULT NULL COMMENT '数量',
  `price` double DEFAULT NULL COMMENT '单价',
  `status` varchar(2000) DEFAULT NULL COMMENT '状态 订单付款 订单结算 订单失效',
  `income_rate` varchar(2000) DEFAULT NULL COMMENT '收入比率',
  `divided_rate` varchar(2000) DEFAULT NULL COMMENT '分成比率',
  `payment` double DEFAULT NULL COMMENT '付款金额',
  `effect_estimate` double DEFAULT NULL COMMENT '效果预估',
  `set_amount` double DEFAULT NULL COMMENT '结算金额',
  `income_estimate` double DEFAULT NULL COMMENT '预估收入',
  `commission_rate` varchar(2000) DEFAULT NULL COMMENT '佣金比率',
  `commission_amount` double DEFAULT NULL COMMENT '佣金金额',
  `subsidy_amount` double DEFAULT NULL COMMENT '补贴金额',
  `order_no` varchar(2000) DEFAULT NULL COMMENT '订单编号',
  `media_id` varchar(2000) DEFAULT NULL COMMENT '媒体id',
  `media_name` varchar(2000) DEFAULT NULL COMMENT '媒体名称',
  `adsense_id` varchar(2000) DEFAULT NULL COMMENT '广告位id',
  `adsense_name` varchar(2000) DEFAULT NULL COMMENT '广告位名称',
  `import_date` datetime DEFAULT NULL COMMENT '导入时间',
  `import_by` bigint(20) DEFAULT NULL COMMENT '导入人id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8 COMMENT='订单表';


insert into abby.tt_order(id,create_date,goods_name,qty,price,status,income_rate,divided_rate,payment,effect_estimate,set_amount,income_estimate,commission_rate,commission_amount,subsidy_amount,order_no,media_id,media_name,adsense_id,adsense_name,import_date,import_by) values (192,'2017-11-05 20:56:43','婚庆玩偶毛绒玩具结婚礼物品布娃娃机小公仔婚礼抛洒抓机娃娃批发',1,2.8,'订单付款','2.00 %','100.00 %',2.75,0.06,0,0,'2.00 %',0,0,'79569052235062215','39356592','Abby省钱帮手A001','146766873','Abby省钱帮手A001','2017-11-05 21:56:49',62);
