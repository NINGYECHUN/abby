USE abby;

CREATE TABLE `tm_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `account` varchar(2000) DEFAULT NULL COMMENT '账号',
  `password` varchar(200) DEFAULT NULL COMMENT '密码',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `pid` varchar(2000) DEFAULT NULL COMMENT 'PID',
  `commission_rate` double DEFAULT NULL COMMENT '提成比率（直接是百分数，比如是10就表示是10%）',
  `is_admin` int(11) DEFAULT '0' COMMENT '是否管理员 1-管理员 0-非管理员',
  `last_login_time` datetime DEFAULT NULL COMMENT '上次登陆时间',
  `alipay` varchar(2000) DEFAULT NULL COMMENT '支付宝账号',
  `phone` varchar(200) DEFAULT NULL COMMENT '手机号码',
  `is_enable` int(11) DEFAULT '1' COMMENT '是否启用 1-启用 0-不启用',
  `gathering_name` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;


insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name) values (57,null,'e10adc3949ba59abbe56e057f20f883e','555','11',10,0,null,null,null,1,null);
insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name) values (58,null,'e10adc3949ba59abbe56e057f20f883e','2222','11',3333,0,null,null,null,1,null);
insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name) values (59,null,'e10adc3949ba59abbe56e057f20f883e','55555',null,null,0,null,null,null,1,null);
insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name) values (60,null,'e10adc3949ba59abbe56e057f20f883e','5','11',11,0,null,null,null,1,null);
insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name) values (61,null,'e10adc3949ba59abbe56e057f20f883e','55','22',11,0,null,null,null,1,null);
insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name) values (62,'13616280075','96e79218965eb72c92a549dd5a330112','张三','22',11,0,'2017-10-12 17:52:14','DDD','2222',1,'王五');
insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name) values (63,'111','e10adc3949ba59abbe56e057f20f883e','22','33',11,0,null,'223','2222',1,null);
insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name) values (64,'11111','e10adc3949ba59abbe56e057f20f883e','3322222222','332333',332333,1,null,'2233233','222233',1,null);
