USE abby;

CREATE TABLE `tt_withdraw_money` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户id',
  `money_qty` double DEFAULT NULL COMMENT '提现金额',
  `withdraw_date` datetime DEFAULT NULL COMMENT '提现时间',
  `status` int(11) DEFAULT NULL COMMENT '状态 1-结算中 2-结算完成 3-结算失败',
  `rmk_user` text COMMENT '用户备注',
  `rmk_admin` text COMMENT '管理员备注',
  `deal_date` datetime DEFAULT NULL COMMENT '结算时间',
  `deal_by` bigint(20) DEFAULT NULL COMMENT '结算人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='提现历史表';


