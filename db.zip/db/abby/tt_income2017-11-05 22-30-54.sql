USE abby;

CREATE TABLE `tt_income` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户id',
  `type` int(11) DEFAULT NULL COMMENT '类型 1-用户当前预期收入 2-用户当前可结算收入 3-下级代理提供的预期收入 4-下级代理提供的可结算收入',
  `amount` double DEFAULT NULL COMMENT '收入',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;


insert into abby.tt_income(id,user_id,type,amount) values (11,68,1,0.03);
