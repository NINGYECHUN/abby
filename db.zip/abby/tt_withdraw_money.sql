USE abby;

CREATE TABLE `tt_withdraw_money` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户id',
  `money_qty` double DEFAULT NULL COMMENT '提现金额',
  `withdraw_date` datetime DEFAULT NULL COMMENT '提现时间',
  `status` int(11) DEFAULT NULL COMMENT '状态 1-结算中 2-结算完成 3-结算失败',
  `rmk_user` text COMMENT '用户备注',
  `rmk_admin` text COMMENT '管理员备注',
  `deal_date` datetime DEFAULT NULL COMMENT '结算时间',
  `deal_by` bigint(20) DEFAULT NULL COMMENT '结算人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='提现历史表';


insert into abby.tt_withdraw_money(id,user_id,money_qty,withdraw_date,status,rmk_user,rmk_admin,deal_date,deal_by) values (1,62,5,'2017-10-12 15:53:07',3,'1111','你没那么多钱','2017-10-12 17:43:30',62);
insert into abby.tt_withdraw_money(id,user_id,money_qty,withdraw_date,status,rmk_user,rmk_admin,deal_date,deal_by) values (2,62,222,'2017-10-12 15:54:17',2,'测试111','已入账','2017-10-12 17:40:54',62);
insert into abby.tt_withdraw_money(id,user_id,money_qty,withdraw_date,status,rmk_user,rmk_admin,deal_date,deal_by) values (3,62,2.33,'2017-10-12 16:32:27',2,'测试2222','已入账','2017-10-12 17:40:54',62);
