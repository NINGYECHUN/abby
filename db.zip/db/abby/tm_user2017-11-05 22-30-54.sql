USE abby;

CREATE TABLE `tm_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `account` varchar(2000) DEFAULT NULL COMMENT '账号',
  `password` varchar(200) DEFAULT NULL COMMENT '密码',
  `name` varchar(200) DEFAULT NULL COMMENT '名称',
  `pid` varchar(2000) DEFAULT NULL COMMENT 'PID',
  `commission_rate` double DEFAULT NULL COMMENT '提成比率（直接是百分数，比如是10就表示是10%）',
  `is_admin` int(11) DEFAULT '0' COMMENT '是否管理员 1-管理员 0-非管理员',
  `last_login_time` datetime DEFAULT NULL COMMENT '上次登陆时间',
  `alipay` varchar(2000) DEFAULT NULL COMMENT '支付宝账号',
  `phone` varchar(200) DEFAULT NULL COMMENT '手机号码',
  `is_enable` int(11) DEFAULT '1' COMMENT '是否启用 1-启用 0-不启用',
  `gathering_name` varchar(2000) DEFAULT NULL,
  `commission_rate_to_parent` double DEFAULT NULL COMMENT '给上级的佣金比率',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '上级代理的用户id',
  `commission_rate_show` double DEFAULT NULL COMMENT '佣金比率（只是用来显示）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;


insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name,commission_rate_to_parent,parent_id,commission_rate_show) values (62,'13616280075','e10adc3949ba59abbe56e057f20f883e','张三','22',11,1,'2017-11-05 21:56:41','DDD','2222',1,'王五',null,null,null);
insert into abby.tm_user(id,account,password,name,pid,commission_rate,is_admin,last_login_time,alipay,phone,is_enable,gathering_name,commission_rate_to_parent,parent_id,commission_rate_show) values (68,'Abby省钱帮手A001','e10adc3949ba59abbe56e057f20f883e','Abby省钱帮手A001','mm_116695559_39356592_146766873',50,0,'2017-11-05 22:27:11',null,null,null,null,null,null,80);
